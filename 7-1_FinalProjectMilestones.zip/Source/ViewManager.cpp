///////////////////////////////////////////////////////////////////////////////
// viewmanager.cpp
// ============
// manage the viewing of 3D objects within the viewport - camera, projection
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>    

// declaration of the global variables and defines
namespace
{
	// Variables for window width and height
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;
	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// camera object used for viewing and interacting with
	// the 3D scene
	Camera* g_pCamera = nullptr;

	// these variables are used for mouse movement processing
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// time between current frame and last frame
	float gDeltaTime = 0.0f; 
	float gLastFrame = 0.0f;

	// projection mode flag: false = perspective, true = orthographic
	bool bOrthographicProjection = false;

	// orthographic projection scale (half-height)
	float g_OrthoScale = 6.0f;

	// last time a scroll event modified movement speed (used to limit adjustment rate)
	double gLastScrollTime = 0.0;
	// maximum allowed absolute speed change per second (units of MovementSpeed/sec)
	const float gMaxSpeedChangePerSecond = 20.0f;

	// bounds for MovementSpeed
	const float gMinMovementSpeed = 1.0f;
	const float gMaxMovementSpeed = 200.0f;
}

/***********************************************************
 *  ViewManager()
 *
 *  The constructor for the class
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager *pShaderManager)
{
	// initialize the member variables
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;
	g_pCamera = new Camera();
	// default camera view parameters (perspective defaults)
	g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f);
	g_pCamera->Front = glm::vec3(0.0f, -0.5f, -2.0f);
	g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
	g_pCamera->Zoom = 80;
	g_pCamera->MovementSpeed = 20;
}

/***********************************************************
 *  ~ViewManager()
 *
 *  The destructor for the class
 ***********************************************************/
ViewManager::~ViewManager()
{
	// free up allocated memory
	m_pShaderManager = NULL;
	m_pWindow = NULL;
	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  This method is used to create the main display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	// try to create the displayed OpenGL window
	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}
	glfwMakeContextCurrent(window);

	// tell GLFW to capture all mouse events
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// this callback is used to receive mouse moving events
	glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);

	// register the scroll callback so mouse wheel events are delivered
	glfwSetScrollCallback(window, &ViewManager::Mouse_Scroll_Callback);

	// register the key callback for toggling projection (P / O)
	glfwSetKeyCallback(window, &ViewManager::Key_Callback);

	// ensure viewport set (hint usage)
	glViewport(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);

	// enable blending for supporting tranparent rendering
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;

	return(window);
}

/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse is moved within the active GLFW display window.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
	// when the first mouse move event is received, this needs to be recorded so that
	// all subsequent mouse moves can correctly calculate the X position offset and Y
	// position offset for proper operation
	if (gFirstMouse)
	{
		gLastX = xMousePos;
		gLastY = yMousePos;
		gFirstMouse = false;
	}

	// calculate the X offset and Y offset values for moving the 3D camera accordingly
	float xOffset = xMousePos - gLastX;
	float yOffset = gLastY - yMousePos; // reversed since y-coordinates go from bottom to top

	// set the current positions into the last position variables
	gLastX = xMousePos;
	gLastY = yMousePos;

	// move the 3D camera according to the calculated offsets
	g_pCamera->ProcessMouseMovement(xOffset, yOffset);
}

/***********************************************************
 *  Key_Callback()
 *
 *  Toggle between perspective and orthographic with keys:
 *   - P : perspective
 *   - O : orthographic
 *
 *  Also adjusts camera defaults appropriate to each projection.
 ***********************************************************/
void ViewManager::Key_Callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	if (action != GLFW_PRESS)
		return;

	if (key == GLFW_KEY_O)
	{
		// switch to orthographic
		bOrthographicProjection = true;

		// orthographic camera settings (tweak as needed)
		g_OrthoScale = 6.0f;
		if (g_pCamera)
		{
			g_pCamera->Position = glm::vec3(0.0f, 8.0f, 12.0f);
			g_pCamera->Front = glm::normalize(glm::vec3(0.0f, -0.6f, -1.0f));
			g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
			g_pCamera->MovementSpeed = 10.0f;
		}

		// update viewport (hint usage)
		glViewport(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);

		std::cout << "Switched to ORTHOGRAPHIC view (O)." << std::endl;
	}
	else if (key == GLFW_KEY_P)
	{
		// switch to perspective
		bOrthographicProjection = false;

		// perspective camera settings (restore defaults)
		if (g_pCamera)
		{
			g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f);
			g_pCamera->Front = glm::vec3(0.0f, -0.5f, -2.0f);
			g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
			g_pCamera->Zoom = 80;
			g_pCamera->MovementSpeed = 20.0f;
		}

		// update viewport (hint usage)
		glViewport(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);

		std::cout << "Switched to PERSPECTIVE view (P)." << std::endl;
	}
}

/***********************************************************
 *  ProcessKeyboardEvents()
 *
 *  This method is called to process any keyboard events
 *  that may be waiting in the event queue.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	// close the window if the escape key has been pressed
	if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(m_pWindow, true);
	}

	// process camera zooming in and out
	if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
	}

	// process camera panning left and right
	if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);
	}
	// process camera panning up and down
	if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)

	{
		g_pCamera->ProcessKeyboard(UP, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(DOWN, gDeltaTime);
	}
}

/***********************************************************
 *  Mouse_Scroll_Callback()
 *
 *  Adjust MovementSpeed using both horizontal (xOffset) and
 *  vertical (yOffset) wheel deltas.  Rate-limited and clamped.
 ***********************************************************/
void ViewManager::Mouse_Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset)
{
	// guard against null camera
	if (NULL == g_pCamera)
		return;

	// per-notch change factors (tweak these to taste)
	const float verticalDeltaPerNotch = 2.5f;    // larger effect for vertical wheel
	const float horizontalDeltaPerNotch = 1.0f;  // horizontal wheel smaller effect

	// desired change from both axes
	float desiredChange = static_cast<float>(yOffset) * verticalDeltaPerNotch
	                    + static_cast<float>(xOffset) * horizontalDeltaPerNotch;

	// compute elapsed time since last scroll adjustment and cap change per time
	double currentTime = glfwGetTime();
	double deltaT = currentTime - gLastScrollTime;
	if (deltaT <= 0.0)
	{
		// first scroll or time didn't advance: allow a single small change allowance
		deltaT = 0.016; // ~1/60s
	}

	// maximum allowed absolute change for this event
	float maxAllowedChange = gMaxSpeedChangePerSecond * static_cast<float>(deltaT);

	// clamp desiredChange to the allowed rate
	if (desiredChange > maxAllowedChange) desiredChange = maxAllowedChange;
	if (desiredChange < -maxAllowedChange) desiredChange = -maxAllowedChange;

	// apply change and clamp MovementSpeed
	float newSpeed = g_pCamera->MovementSpeed + desiredChange;
	if (newSpeed < gMinMovementSpeed) newSpeed = gMinMovementSpeed;
	if (newSpeed > gMaxMovementSpeed) newSpeed = gMaxMovementSpeed;
	g_pCamera->MovementSpeed = newSpeed;

	// update last scroll time
	gLastScrollTime = currentTime;

	// debug output (remove or guard behind a verbose flag if desired)
	std::cout << "Camera movement speed: " << g_pCamera->MovementSpeed << std::endl;
}

/***********************************************************
 *  PrepareSceneView()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// per-frame timing
	float currentFrame = glfwGetTime();
	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	// process any keyboard events that may be waiting in the 
	// event queue
	ProcessKeyboardEvents();

	// get the current view matrix from the camera
	view = g_pCamera->GetViewMatrix();

	// define the current projection matrix depending on mode
	if (bOrthographicProjection)
	{
		// orthographic: compute bounds from ortho scale and aspect ratio
		float aspect = static_cast<float>(WINDOW_WIDTH) / static_cast<float>(WINDOW_HEIGHT);
		float halfH = g_OrthoScale;
		float halfW = aspect * halfH;
		projection = glm::ortho(-halfW, halfW, -halfH, halfH, 0.1f, 100.0f);
	}
	else
	{
		// perspective
		projection = glm::perspective(glm::radians(g_pCamera->Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
	}

	// if the shader manager object is valid
	if (NULL != m_pShaderManager)
	{
		// set the view matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ViewName, view);
		// set the projection matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ProjectionName, projection);
		// set the view position of the camera into the shader for proper rendering
		m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
	}
}